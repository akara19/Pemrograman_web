<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Barang_group extends CI_Controller {
	public function index()
	{
		$this->load->view('barang_group/form');
	}

	public function Insert(){
		$data = array('Nama' => $this->input->post('Nama')
        );
        $this->db->insert('barang_group',$data);
        echo "<meta http-equiv='refresh' content='0; url=".base_url()."index.php/Barang_group'>"; 
	}

	public function form(){
		$this->load->view('v_form');
	}

	public function kirim_data(){
		$nim = $this->input->post('nim');
		$nama = $this->input->post('nama');
		$data['nim'] = $nim;
		$data['nama']= $nama;
		
		echo $nim."<br>";
		echo $nama;
		
		//$this->load->view('v_tangkap',$data);
	}
}
