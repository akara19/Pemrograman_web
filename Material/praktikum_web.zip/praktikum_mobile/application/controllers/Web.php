<?php
error_reporting(0);
class Web extends CI_Controller{

	function __construct() {
		parent::__construct();
        $this->load->helper(array('form','url', 'text_helper','date'));
		$this->load->database();
		$this->load->library(array('Pagination','user_agent'));
		$this->load->model(array('Ppi_job_model',
								 'Ppi_pengumuman_model',
								 'Ppi_berita_model',
								 'Ppi_event_model'));
	}

	function index(){
		$data['Hasil'] = $this->Ppi_job_model->ppi_job_view()->result();
		$this->template->load('web','web/index',$data);
	}

	function detil_pengumuman(){
		$fppi_id =  $this->uri->segment(3);
		$data['Hasil'] = $this->Ppi_pengumuman_model->web_pengumuman_view_detil($fppi_id)->result();
		$this->template->load('web','web/Pengumuman_detil',$data);
		
	}

	function detil_berita(){
		$fppi_id =  $this->uri->segment(3);
		$data['Hasil'] = $this->Ppi_berita_model->web_berita_view_detil($fppi_id)->result();
		$this->template->load('web','web/Berita_detil',$data);
	}

	function detil_event(){
		$fppi_id =  $this->uri->segment(3);
		$data['Hasil'] = $this->Ppi_event_model->web_event_view_detil($fppi_id)->result();
		$this->template->load('web','web/Event_detil',$data);
	}

	function detil_job(){
		$fppi_id =  $this->uri->segment(3);
		$data['Hasil'] = $this->Ppi_job_model->web_job_view_detil($fppi_id)->result();
		$this->template->load('web','web/Job_detil',$data);
	}
}
?>
