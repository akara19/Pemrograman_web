<?php
//error_reporting(0);
class Dashboard extends CI_Controller{

	function __construct() {
		parent::__construct();
        $this->load->helper(array('form','url', 'text_helper','date'));
		$this->load->database();
		$this->load->library(array('Pagination','user_agent'));
		$this->load->model(array('Ppi_barang_model',
								'Combo_box_model'));
	}
	
	function index(){
		$data['Barang'] = $this->Combo_box_model->ppi_barang_lookup()->result();
		$this->template->load('dashboard','webadmin/table/data-table-insert',$data);
	}
	
	function view(){
		//echo "Test";
		$data['Ppi_barang'] = $this->Ppi_barang_model->ppi_barang()->result();
		$this->template->load('dashboard','webadmin/table/data-table',$data);
	}
}
?>
