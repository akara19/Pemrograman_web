<?php
class C_ppi_mahasiswa extends CI_Controller{
	// __contructor default dari controlle
	function __construct() {
		parent::__construct();
		error_reporting(0);
		$this->load->helper(array('form','url','text_helper','date'));
		$this->load->database();
		$this->load->library(array('Pagination','user_agent'));
		$this->load->model(array('M_ppi_mahasiswa'));
	}
	// index untuk tabel ppi_mahasiswa berfungsi untuk menampilkan data pada grid
	function index(){
		$data['Type']="Tambah Data Mahasiswa";
		$this->template->load('V_dashboard','webadmin/Ppi_mahasiswa/V_ppi_mahasiswa_insert',$data);
	}
	// form tambah data untuk tabel ppi_mahasiswa
	function View(){
		$data['Type']="Data Mahasiswa";
		$data['Ppi_mahasiswa'] = $this->M_ppi_mahasiswa->ppi_mahasiswa_view()->result();
		$this->template->load('V_dashboard','webadmin/Ppi_mahasiswa/V_ppi_mahasiswa',$data);
	}
	// Method atau function untuk menangkap data form ppi_mahasiswa
	// dan selanjut nya akan di lempar ke SP insert
	// dan melakukan penyimpanan data pada tabel ppi_mahasiswa
	function Insert(){
		$session = isset($_SESSION['user_login']) ? $_SESSION['user_login']:'';
		$pecah = explode("|",$session);
		$data["ppi_id"]	= $pecah[0];
		// Variabel yang digunakan untuk menangkap isi dari form input data
		$Nama = $this->input->post('Nama');		$Nim = $this->input->post('Nim');		$No_telp = $this->input->post('No_telp');
		// Memanggil method atau fungsi untuk menyimpan data pada Model 
		$this->M_ppi_mahasiswa->Ppi_mahasiswa_insert(		$Nama,		$Nim,		$No_telp		,$data['id_user']);
	$this->session->set_flashdata('msg', 
                '<div class="alert alert-success alert-dismissible fade in">
                	<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                    <strong>Data baru berhasil disimpan</strong>
                    </div>');
		echo "<meta http-equiv='refresh' content='0; url=".base_url()."index.php/C_ppi_mahasiswa'>";
	}
	// Form Edit untuk tabel ppi_mahasiswa berfungsi untuk memanggil form edit atau ubah data
	function Edit(){
		$fid = $this->uri->segment(3);
		$data['Type']="Edit / Ubah Data Mahasiswa";
		$data['Ppi_mahasiswa']=$this->M_ppi_mahasiswa->Ppi_mahasiswa_view_edit($fid)->result();
		$this->template->load('V_dashboard','webadmin/Ppi_mahasiswa/V_ppi_mahasiswa_edit',$data);
	}
	// Method atau function untuk menangkap data form ppi_mahasiswa
	// dan selanjut nya akan di lempar ke SP Update
	// dan melakukan penyimpanan data pada tabel ppi_mahasiswa
	function Update(){
		$session = isset($_SESSION['user_login']) ? $_SESSION['user_login']:'';
		$pecah = explode("|",$session);
		$data["id_user"]	= $pecah[0];
		// variabel yang digunakan sebagai acuan untuk melakukan proses Update
		$Id = $this->input->post('id');
		// Variabel yang digunakan untuk menamgkap isi dari form input data
		$Nama = $this->input->post('Nama');		$Nim = $this->input->post('Nim');		$No_telp = $this->input->post('No_telp');		
		// Memanggil method atau fungsi untuk menyimpan data pada Model 
		$this->M_ppi_mahasiswa->Ppi_mahasiswa_update(		$Id,$Nama,		$Nim,		$No_telp		,$data['id_user']);
	$this->session->set_flashdata('msg', 
                '<div class="alert alert-success alert-dismissible fade in">
                	<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                    <strong>Perubahan data berhasil disimpan !!</strong>
                    </div>');
		echo "<meta http-equiv='refresh' content='0; url=".base_url()."index.php/C_ppi_mahasiswa/Edit'>";
	}
	// form tambah data untuk tabel ppi_mahasiswa
	function Delete(){
		$Id = $this->uri->segment(3);
		$this->M_ppi_mahasiswa->Ppi_mahasiswa_delete($Id);
		echo "<meta http-equiv='refresh' content='0; url=".base_url()."index.php/C_ppi_mahasiswa/View'>";
	}
// End Class
}
?>
