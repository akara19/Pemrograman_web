<?php
class Dashboard_model extends CI_Model{

	function jumlah_stake_holder(){
		$a_procedure = 'SELECT jumlah_stake_holder() AS Jml';
		$a_result= $this->db->query($a_procedure);
		mysqli_next_result( $this->db->conn_id);
		return $a_result;
	}
	
	// Function / method insert menampilkan data mahasiswa berdasarkan penguji
	function grafik_lulusan(){
		$a_procedure = 'CALL grafik_lulusan';
		$a_result= $this->db->query($a_procedure);
		mysqli_next_result( $this->db->conn_id);
		return $a_result;
	}
	
	// Untuk menampilkan nilai mahasiswa yag sudah fix
	function nilai_mahasiswa(){
		$a_procedure = 'CALL nilai_mahasiswa';
		$a_result= $this->db->query($a_procedure);
		mysqli_next_result( $this->db->conn_id);
		return $a_result;
	}
	
	// Function / method delete data ppi_komponen
	function nilai_check_true_false($fKode_mahasiswa){
		$a_procedure = 'CALL nilai_check_true_false(?)';
		$a_result= $this->db->query($a_procedure,array(
			'fKode_mahasiswa'=>$fKode_mahasiswa
		));
		mysqli_next_result( $this->db->conn_id);
		return $a_result;
	}

	// Function / method select data ppi_komponen untuk proses edit data
	function nilai_edit($fKode_mahasiswa){
		$a_procedure = 'CALL Nilai_edit(?)';
		$a_result= $this->db->query($a_procedure,array(
			'fKode_mahasiswa'=>$fKode_mahasiswa
		));
		mysqli_next_result( $this->db->conn_id);
		return $a_result;
	}
	
	// Function untuk mengetahui jumlah mahasiswa yang sudah mengisi Quesuione
	// Function / method select data ppi_komponen untuk proses edit data
	function jumlah_mahasiswa_isi_quesioner(){
		$a_procedure = 'CALL jumlah_mahasiswa_isi_quesioner';
		$a_result= $this->db->query($a_procedure);
		mysqli_next_result( $this->db->conn_id);
		return $a_result;
	}
	

// End Class
}
?>
