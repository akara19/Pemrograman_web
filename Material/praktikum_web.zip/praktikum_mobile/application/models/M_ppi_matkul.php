<?php
class M_ppi_matkul extends CI_Model{
	// Function / method insert data ppi_matkul
	function ppi_matkul_insert(		$fNama,		$fSks,		$fUser_create){
		$a_procedure = 'CALL ppi_matkul_insert(		?,		?,		?)';
		$a_result= $this->db->query($a_procedure,array(			'fNama'=>$fNama,			'fSks'=>$fSks,
			'fUser_create'=>$fUser_create
		));
		return $a_result;
	}
	// Function / method Update data ppi_matkul
	function ppi_matkul_update(		$fppi_id,		$fNama,		$fSks,		$fUser_create){
		$a_procedure = 'CALL ppi_matkul_update(		?,		?,		?,		?)';
		$a_result= $this->db->query($a_procedure,array(			'fppi_id'=>$fppi_id,			'fNama'=>$fNama,			'fSks'=>$fSks,
			'fUser_create'=>$fUser_create
		));
		return $a_result;
	}
	// Function / method delete data ppi_matkul
	function ppi_matkul_delete($fppi_id){
		$a_procedure = 'CALL ppi_matkul_delete(?)';
		$a_result= $this->db->query($a_procedure,array(			'fppi_id'=>$fppi_id
		));
		return $a_result;
	}
	// Function / method select data ppi_matkul
	function ppi_matkul_view(){
		$a_procedure = 'CALL ppi_matkul_view';
		$a_result= $this->db->query($a_procedure);
		return $a_result;
	}
	// Function / method select data ppi_matkul untuk proses edit data
	function ppi_matkul_view_edit($fppi_id){
		$a_procedure = 'CALL ppi_matkul_view_edit(?)';
		$a_result= $this->db->query($a_procedure,array(			'fppi_id'=>$fppi_id
		));
		return $a_result;
	}
// End Class
}
?>
