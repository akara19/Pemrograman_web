<?php
class M_ppi_mahasiswa extends CI_Model{
	// Function / method insert data ppi_mahasiswa
	function ppi_mahasiswa_insert(		$fNama,		$fNim,		$fNo_telp,		$fUser_create){
		$a_procedure = 'CALL ppi_mahasiswa_insert(		?,		?,		?,		?)';
		$a_result= $this->db->query($a_procedure,array(			'fNama'=>$fNama,			'fNim'=>$fNim,			'fNo_telp'=>$fNo_telp,
			'fUser_create'=>$fUser_create
		));
		return $a_result;
	}
	// Function / method Update data ppi_mahasiswa
	function ppi_mahasiswa_update(		$fppi_id,		$fNama,		$fNim,		$fNo_telp,		$fUser_create){
		$a_procedure = 'CALL ppi_mahasiswa_update(		?,		?,		?,		?,		?)';
		$a_result= $this->db->query($a_procedure,array(			'fppi_id'=>$fppi_id,			'fNama'=>$fNama,			'fNim'=>$fNim,			'fNo_telp'=>$fNo_telp,
			'fUser_create'=>$fUser_create
		));
		return $a_result;
	}
	// Function / method delete data ppi_mahasiswa
	function ppi_mahasiswa_delete($fppi_id){
		$a_procedure = 'CALL ppi_mahasiswa_delete(?)';
		$a_result= $this->db->query($a_procedure,array(			'fppi_id'=>$fppi_id
		));
		return $a_result;
	}
	// Function / method select data ppi_mahasiswa
	function ppi_mahasiswa_view(){
		$a_procedure = 'CALL ppi_mahasiswa_view';
		$a_result= $this->db->query($a_procedure);
		return $a_result;
	}
	// Function / method select data ppi_mahasiswa untuk proses edit data
	function ppi_mahasiswa_view_edit($fppi_id){
		$a_procedure = 'CALL ppi_mahasiswa_view_edit(?)';
		$a_result= $this->db->query($a_procedure,array(			'fppi_id'=>$fppi_id
		));
		return $a_result;
	}
// End Class
}
?>
