<?php
class Menu_model extends CI_Model{

	function Show_menu(){
		$a_procedure = 'CALL ppi_user_menu';
		$a_result= $this->db->query($a_procedure);
		mysqli_next_result( $this->db->conn_id);
		return $a_result;
	}

// End Class
}
?>
