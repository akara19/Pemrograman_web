<!DOCTYPE html>
<html><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<title>Info Karir | Akper Dharma Husada Kota Kediri</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="<?php echo base_url()?>asset/css/web/w3.css">
<link rel="stylesheet" href="<?php echo base_url()?>asset/css/web/w3-theme-blue-grey.css">
<link rel="stylesheet" href="<?php echo base_url()?>asset/css/web/css.css">
<link rel="stylesheet" href="<?php echo base_url()?>asset/css/font-awesome.css">
<!-- Bootstrap -->
<link rel="stylesheet" href="<?php echo base_url()?>asset/css/bootstrap.min.css">
<script src="<?php echo base_url()?>asset/js/jquery.min.js"></script>
<script src="<?php echo base_url()?>asset/js/bootstrap.min.js"></script>
<script src="<?php echo base_url()?>asset/js/bootstrap.js"></script>
<style>
html, body, h1, h2, h3, h4, h5 {font-family: "Open Sans", sans-serif}
</style>

</head><body class="w3-theme-l5">

<!-- Navbar -->
<div class="w3-top">
 <div class="w3-bar w3-theme-y1 w3-left-align w3-large w3-border-solid-y1">
 <a class="w3-bar-item w3-button w3-hide-medium w3-hide-large w3-right w3-padding-large w3-hover-white w3-large w3-theme-d2" href="javascript:void(0);" onclick="openNav()"><i class="fa fa-bars"></i></a>
  <a href="" class="w3-bar-item w3-button w3-padding-large">
  <img src="<?php echo base_url()?>asset/logo.png" style="width:60px; height:60px" class="w3-circle">
  </a>
  <a href="<?php echo base_url()?>index.php/Web" class="w3-bar-item w3-button w3-hide-small w3-padding-large w3-hover-white" title="Home">
  <i class="fa fa-home"><h4>Home</h4></i>
  </a>
  <a href="http://mahasiswa.adhkediri.ac.id/" class="w3-bar-item w3-button w3-hide-small w3-padding-large w3-hover-white" title="Register"
  target="_blank">
  <i class="fa fa-user"><h4>Tracer Study</h4></i>
</a>

  <!--
  <div class="w3-dropdown-hover w3-hide-small">
    <button class="w3-button w3-padding-large w3-hover-green" title="Notifications"><i class="fa fa-bell"></i><span class="w3-badge w3-right w3-small w3-green">3</span></button>
    <div class="w3-dropdown-content w3-card-4 w3-bar-block" style="width:300px">
      <a href="#" class="w3-bar-item w3-button">One new friend request</a>
      <a href="#" class="w3-bar-item w3-button">John Doe posted on your wall</a>
      <a href="#" class="w3-bar-item w3-button">Jane likes your post</a>
    </div>
  </div>
  <a href="#" class="w3-bar-item w3-button w3-hide-small w3-right w3-padding-large w3-hover-white" title="My Account">
    <img src="W3.CSS%20Template_files/avatar2.png" class="w3-circle" style="height:23px;width:23px" alt="">
  </a> -->
 </div>
</div>

<!-- Navbar on small screens -->
<div id="navDemo" class="w3-bar-block w3-theme-g1 w3-hide w3-hide-large w3-hide-medium w3-large">

  <a href="#" class="w3-bar-item w3-button w3-padding-large">Home</a>
  <a href="#" class="w3-bar-item w3-button w3-padding-large">Home</a>
  <a href="<?php echo base_url()?>index.php/Web" class="w3-bar-item w3-button w3-padding-large">Home</a>
  <a href="#" class="w3-bar-item w3-button w3-padding-large">My Profile</a>
</div>

<!-- Page Container -->
<div class="w3-container w3-content" style="max-width:1400px;margin-top:100px">
  <!-- The Grid -->
  <div class="w3-row">
    <!-- Left Column -->
    <div class="w3-col m3">
      <!-- Pengumuman -->
      <div class="w3-card w3-round w3-white">
        <div class="w3-container">
         <div class="panel panel-info" style="margin-top:10px">
			<div class="panel-heading">Pengumuman</div>
			<?php
			$qry_pengumuman = "CALL web_ppi_pengumuman";
			$pengumuman = $this->db->query($qry_pengumuman);
			mysqli_next_result( $this->db->conn_id);
			foreach ($pengumuman->result() as $_pengumuman){
				echo "<div class='panel-body'>".$_pengumuman->Keterangan."".
					 "<span class='w3-right w3-opacity'>".$_pengumuman->Created."</span>".
					 anchor(base_url('index.php/Web/detil_pengumuman/'.$_pengumuman->ppi_id),
					 $_pengumuman->Nama,
					 array('class'=>'w3-button w3-block w3-theme-l4'));
				echo
					 "</div>";
			}
			?>

		 </div>
        </div>
      </div>
      <br>

      <!-- Berita -->
      <div class="w3-card w3-round w3-white">
        <div class="w3-container">
         <div class="panel panel-info" style="margin-top:10px">
			<div class="panel-heading">Berita</div>
			<?php
			$qry_berita = "CALL web_ppi_berita";
			$berita = $this->db->query($qry_berita);
			mysqli_next_result( $this->db->conn_id);
			foreach ($berita->result() as $_berita){
				echo "<div class='panel-body'>".$_berita->Nama.
					 "<span class='w3-right w3-opacity'>".$_berita->Created."</span>".
					 anchor(base_url('index.php/Web/detil_berita/'.$_berita->ppi_id),
					 $_berita->Nama,
					 array('class'=>'w3-button w3-block w3-theme-l4'));
				echo "</div>";
			}
			?>

		</div>
        </div>
      </div>
      <br>

    <!-- End Left Column -->
    </div>

    <!-- Middle Column -->
    <div class="w3-col m7">

     <?php echo $contents; ?>

    <!-- End Middle Column -->
    </div>

    <!-- Right Column -->
    <div class="w3-col m2">
      <div class="w3-card w3-round w3-white w3-center">
        <div class="w3-container">
        <div class="panel panel-info" style="margin-top:10px">
        <div class="panel-heading">Events</div>
          <!-- <img src="W3.CSS%20Template_files/forest.jpg" alt="Forest" style="width:100%;"> -->
          <?php
          	$qry_event = "CALL web_ppi_event";
			$event = $this->db->query($qry_event);
			mysqli_next_result( $this->db->conn_id);
			foreach ($event->result() as $_event){
			echo
				"<p><strong>".$_event->Nama."</strong></p>".
          		"<p>".$_event->Tanggal."<br>".$_event->Waktu."<br>".$_event->Tempat."</p>".
          		"<p>".$_event->Penyelenggara."</p> <p>".
          		anchor(base_url('index.php/Web/detil_event/'.$_event->ppi_id),'Info',
					 array('class'=>'w3-button w3-block w3-theme-l4'));
				echo "</p>";

			}
          ?>
</div>
        </div>
      </div>
      <br>

      <div class="w3-card w3-round w3-white w3-center">
        <div class="w3-container">
          <div class="panel panel-info" style="margin-top:10px">
          <div class="panel-heading">Info Job Terbaru</div>
          <img src="W3.CSS%20Template_files/avatar6.png" alt="" style="width:50%"><br>
          <div class="w3-row w3-opacity">
            <?php
              $qry_job = "CALL web_job_view_terbaru";
              $job = $this->db->query($qry_job);
              mysqli_next_result( $this->db->conn_id);
              foreach ($job->result() as $_job){
                  echo  anchor(base_url('index.php/Web/detil_job/'.$_job->ppi_id),$_job->Nama.'<br>'.$_job->Instansi_stake_holder,
       					 array('data-toggle'=>'popover',
                            'data-html'=>'true',
                            'data-container'=>'body',
                            'data-placement' =>'right',
                            'data-content'=>$_job->Deskripsi));
                }
            ?>
          </div>
          </div>
        </div>
      </div>
      <!-- End Right Column -->
    </div>

  <!-- End Grid -->
  </div>

<!-- End Page Container -->
</div>
<br>

<!-- Footer -->
<footer class="w3-container w3-theme-y1 w3-padding-16 text-center">
  <h5>Akademi Keperawatan Dharma Husada Kota Kediri<br>
	Jln. Penanggungan No.41 A Kota Kediri (64114) - Jawa Timur<br>
	Telp & Fax: 0354-772628 email : akperdh@gmail.com</h5>
</footer>

<footer class="w3-container w3-theme-d5 text-center">
  <p>
  Powered by <a href="https://www.w3schools.com/w3css/default.asp" target="_blank">w3.css </a>
  | Maintenance By <a href="http://www.devindonesia.com/" target="_blank">Devindonesia</a>
  </p>
</footer>

<script>
// Accordionz
function myFunction(id) {
  var x = document.getElementById(id);
  if (x.className.indexOf("w3-show") == -1) {
    x.className += " w3-show";
    x.previousElementSibling.className += " w3-theme-d1";
  } else {
    x.className = x.className.replace("w3-show", "");
    x.previousElementSibling.className =
    x.previousElementSibling.className.replace(" w3-theme-d1", "");
  }
}

// Used to toggle the menu on smaller screens when clicking on the menu button
function openNav() {
  var x = document.getElementById("navDemo");
  if (x.className.indexOf("w3-show") == -1) {
    x.className += " w3-show";
  } else {
    x.className = x.className.replace(" w3-show", "");
  }
}
</script>
<!-- Script -->



</body></html>
