<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
  	<title>Dev Indonesia | Template</title>
  	<!-- Tell the browser to be responsive to screen width -->
  	<meta name="viewport" content="width=device-width, initial-scale=1">

<?php
		//Function TinyMce------------------------------------------------------------------
		echo'
		<!-- TinyMCE -->
		<script type="text/javascript" src="'.base_url().'asset/tiny_mce/tiny_mce_src.js"></script>
		<script type="text/javascript">
			tinyMCE.init({
				// General options
				mode : "textareas",
				theme : "advanced",
				plugins : "pagebreak,style,layer,table,save,advhr,advimage,advlink,emotions,iespell,inlinepopups,insertdatetime,preview,media,searchreplace,print,contextmenu,paste,directionality,fullscreen,noneditable,visualchars,nonbreaking,xhtmlxtras,template,wordcount,advlist,autosave",

				// Theme options
				theme_advanced_buttons1 : "save,newdocument,|,bold,italic,underline,strikethrough,|,justifyleft,justifycenter,justifyright,justifyfull,styleselect,formatselect,fontselect,fontsizeselect",
				theme_advanced_buttons2 : "cut,copy,paste,pastetext,pasteword,|,search,replace,|,bullist,numlist,|,outdent,indent,blockquote,|,undo,redo,|,link,unlink,anchor,image,cleanup,help,code,|,insertdate,inserttime,preview,|,forecolor,backcolor",
				theme_advanced_buttons3 : "tablecontrols,|,hr,removeformat,visualaid,|,sub,sup,|,charmap,emotions,iespell,media,advhr,|,print,|,ltr,rtl,|,fullscreen",
				theme_advanced_buttons4 : "insertlayer,moveforward,movebackward,absolute,|,styleprops,|,cite,abbr,acronym,del,ins,attribs,|,visualchars,nonbreaking,template,pagebreak,restoredraft",
				theme_advanced_toolbar_location : "top",
				theme_advanced_toolbar_align : "left",
				theme_advanced_statusbar_location : "bottom",
				theme_advanced_resizing : true,

				// Example content CSS (should be your site CSS)
				//content_css : "'.base_url().'system/application/views/themes/css/BrightSide.css",

				// Drop lists for link/image/media/template dialogs
				//"'.base_url().'media/lists/image_list.js"
				template_external_list_url : "lists/template_list.js",
				external_link_list_url : "lists/link_list.js",
				external_image_list_url : "'.base_url().'index.php/webadmin/image_list/",
				media_external_list_url : "lists/media_list.js",

				// Style formats
				style_formats : [
					{title : \'Bold text\', inline : \'b\'},
					{title : \'Red text\', inline : \'span\', styles : {color : \'#ff0000\'}},
					{title : \'Red header\', block : \'h1\', styles : {color : \'#ff0000\'}},
					{title : \'Example 1\', inline : \'span\', classes : \'example1\'},
					{title : \'Example 2\', inline : \'span\', classes : \'example2\'},
					{title : \'Table styles\'},
					{title : \'Table row 1\', selector : \'tr\', classes : \'tablerow1\'}
				],
				//disabled relative urls
				relative_urls : false,

				// Replace values for the template plugin
				template_replace_values : {
					username : "Some User",
					staffid : "991234"
				}
			});
		</script>';
		?>
	

	
<!-- 
==============================================================
Material desain untuk tampilan dashboard 
untuk tampilan dashboad menggunakan boootstrap 4
dengan template adminLte V3
material ini bersifat wajib :)
=========================================================
-->
<!-- Font Awesome -->
<link rel="stylesheet" href="<?php echo base_url() ?>asset/adminlte/plugins/fontawesome-free/css/all.min.css">
<!-- Ionicons 
		<link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css"> -->
<!-- overlayScrollbars -->
<link rel="stylesheet" href="<?php echo base_url() ?>asset/adminlte/dist/css/adminlte.min.css">
<!-- Google Font: Source Sans Pro 
		<link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet"> -->
<!-- 
============================================================
Akhir material desain untuk tampilan admin 
===========================================================
-->
	

		<!-- favicon
		============================================ -->
		<link rel="shortcut icon" type="image/x-icon" href="<?php echo base_url()?>asset/SimbolSuccess.ico">
		<!-- Google Fonts
		============================================ 
		<link href="https://fonts.googleapis.com/css?family=Play:400,700" rel="stylesheet"> -->
		<!-- Bootstrap CSS
		============================================ -->
		<link rel="stylesheet" href="<?php echo base_url() ?>asset/css/bootstrap.min.css">  
		<!-- Bootstrap CSS
		============================================ 
		<link rel="stylesheet" href="<?php echo base_url() ?>asset/css/font-awesome.min.css">  -->
		<!-- owl.carousel CSS
		============================================ -->
		<link rel="stylesheet" href="<?php echo base_url() ?>asset/css/owl.carousel.css">
		<link rel="stylesheet" href="<?php echo base_url() ?>asset/css/owl.theme.css">
		<link rel="stylesheet" href="<?php echo base_url() ?>asset/css/owl.transitions.css">
		<!-- animate CSS
		============================================ -->
		<link rel="stylesheet" href="<?php echo base_url() ?>asset/css/animate.css">
		<!-- normalize CSS
		============================================ -->
		<link rel="stylesheet" href="<?php echo base_url() ?>asset/css/normalize.css">
		<!-- meanmenu icon CSS
		============================================ -->
		<link rel="stylesheet" href="<?php echo base_url() ?>asset/css/meanmenu.min.css">
		<!-- main CSS
		============================================ -->
		<link rel="stylesheet" href="<?php echo base_url() ?>asset/css/main.css">
		<!-- morrisjs CSS
		============================================ -->
		<link rel="stylesheet" href="<?php echo base_url() ?>asset/css/morrisjs/morris.css">
		<!-- mCustomScrollbar CSS
		============================================ -->
		<link rel="stylesheet" href="<?php echo base_url() ?>asset/css/scrollbar/jquery.mCustomScrollbar.min.css">
		<!-- metisMenu CSS
		============================================ -->
		<link rel="stylesheet" href="<?php echo base_url() ?>asset/css/metisMenu/metisMenu.min.css">
		<link rel="stylesheet" href="<?php echo base_url() ?>asset/css/metisMenu/metisMenu-vertical.css">
		<!-- calendar CSS
		============================================ -->
		<link rel="stylesheet" href="<?php echo base_url() ?>asset/css/calendar/fullcalendar.min.css">
		<link rel="stylesheet" href="<?php echo base_url() ?>asset/css/calendar/fullcalendar.print.min.css">
		<!-- x-editor CSS
		============================================ -->
		<link rel="stylesheet" href="<?php echo base_url() ?>asset/css/editor/select2.css">
		<link rel="stylesheet" href="<?php echo base_url() ?>asset/css/editor/datetimepicker.css">
		<link rel="stylesheet" href="<?php echo base_url() ?>asset/css/editor/bootstrap-editable.css">
		<link rel="stylesheet" href="<?php echo base_url() ?>asset/css/editor/x-editor-style.css">
		<!-- normalize CSS
		============================================ -->
		<link rel="stylesheet" href="<?php echo base_url() ?>asset/css/data-table/bootstrap-table.css">
		<link rel="stylesheet" href="<?php echo base_url() ?>asset/css/data-table/bootstrap-editable.css">
		<!-- style CSS
		============================================ -->
		<link rel="stylesheet" href="<?php echo base_url() ?>asset/style.css">
		<!-- responsive CSS
		============================================ -->
		<link rel="stylesheet" href="<?php echo base_url() ?>asset/css/responsive.css"> 
		<!-- modernizr JS
		============================================ -->
		<script src="<?php echo base_url() ?>asset/js/vendor/modernizr-2.8.3.min.js"> </script>

		<!-- Sweet Alert -->
		<link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>asset/sweet_alert/sweetalert.css">

		<!-- select2 CSS
		============================================ -->
		<link rel="stylesheet" href="<?php echo base_url() ?>asset/css/select2/select2.min.css">
		<!-- chosen CSS
		============================================ -->
		<link rel="stylesheet" href="<?php echo base_url() ?>asset/css/chosen/bootstrap-chosen.css">

		<!-- style CSS Alert
		============================================ -->
		<link rel="stylesheet" href="<?php echo base_url() ?>asset/css/alerts.css">
		<!-- CopyToClipboard
		============================================ -->
		<script src="<?php echo base_url() ?>asset/js/clipboard/clipboard.min.js"> </script>

  
</head>
<body class="hold-transition sidebar-mini">
<!-- Site wrapper -->
<div class="wrapper">
  <!-- Navbar -->
  <nav class="main-header navbar navbar-expand navbar-white navbar-light">
    <!-- Left navbar links -->
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
      </li>
      <li class="nav-item d-none d-sm-inline-block">
        <?php echo anchor(base_url(),'Home',array('class'=>'nav-link')); ?>
      </li>
      
    </ul>


    <!-- Right navbar links -->
    <ul class="navbar-nav ml-auto">
         
      <li class="nav-item">
        <a class="nav-link" data-widget="control-sidebar" data-slide="true" href="#" role="button">
          <i class="fas fa-th-large"></i>
        </a>
      </li>
    </ul>
  </nav>
  <!-- /.navbar -->

  <!-- Main Sidebar Container -->
  <aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
    <a href="#" class="brand-link">
      <img src="<?php echo base_url()?>asset/SimbolSuccess.png"
           alt="AdminLTE Logo"
           class="brand-image img-circle elevation-3"
           style="opacity: .8">
      <span class="brand-text font-weight-light">Dev Indonesia</span>
    </a>

    <!-- Sidebar -->
    <div class="sidebar">
      <!-- Sidebar user (optional) -->
      <div class="user-panel mt-3 pb-3 mb-3 d-flex">
        <div class="image">
          <img src="<?php echo base_url()?>asset/SimbolSuccess.png" 
          class="img-circle elevation-2" alt="User Image">
        </div>
        <div class="info">
          <a href="#" class="d-block">By Dev Indonesia</a>
        </div>
      </div>

      <!-- Sidebar Menu -->
      <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" 
        data-accordion="false">
          <!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->
				
         	<?php
			// data main menu
			$main_menu = $this->db->get_where('ppi_menu', array('Is_menu_main' => 0));
			/**
			* 
			* Foreach Menu Utama
			* 
			*/
			foreach ($main_menu->result() as $main) {
			// Query untuk mencari data sub menu
			$sub_menu = $this->db->order_by('Urutan_menu','ASC')->get_where('ppi_menu', array('Is_menu_main' => $main->ppi_id));
			// periksa apakah ada sub menu
				if ($sub_menu->num_rows() > 0) {
				?>
					<li class="nav-item has-treeview">
						<!--
						<a href="#" class="nav-link">
						<i class="nav-icon fas fa-tachometer-alt"></i>
						<p>
						<?php echo $main->Nama; ?>
						<i class="right fas fa-angle-left"></i>
						</p>
						</a>
						-->
						<?php
						echo anchor($main->Link,'<i class="nav-icon fas '.$main->Icon.'"></i> <p>'.
						$main->Nama."<i class='right fas fa-angle-left'></i></p>",
						array('class'=>'nav-link'));
						?>
						
						<ul class="nav nav-treeview">
							<?php
							/**
							* 
							* Untuk menampilkan sub menu
							*  anchor($main->Link, '<i class="' . $main->Icon . '"></i> ' . $main->Nama .
									'<span class="pull-right-container">
                                                <i class="fa fa-angle-left pull-right"></i>
                                            </span>');
							*/	
							foreach ($sub_menu->result() as $sub) {
							?>
								<li class="nav-item">
									<?php echo anchor($sub->Link,'<i class="far '.$sub->Icon.'"></i> <p>'
										.$sub->Nama.'</p>',array("class"=>'nav-link')); 
									?>
									<!--
									<a href="../../index.html" class="nav-link">
										<i class="far fa-circle nav-icon"></i>
										<p>Dashboard v1</p>
									</a>-->
								</li>
							<?php
							/**
							*
							* Akhir Sub menu
							*
							*/
							}
						?>
						
						</ul>
					</li>
				<?php } else {?>
				<li class="nav-item">
				<a href="pages/widgets.html" class="nav-link">
					<i class="nav-icon fas fa-th"></i>
					<p>	Widgets <span class="right badge badge-danger">New</span>
					</p>
				</a>
				</li>
				<?php } ?>
			<?php
			/**
			*
			* End Foreach Menu Utama
			*
			*/
			}
			?>
          
        </ul>
      </nav>
      <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
  </aside>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
 	<?php echo $contents; ?> 		
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <footer class="main-footer">
    <div class="float-right d-none d-sm-block">
      <b>Version</b> 3.0.4
    </div>
    <strong>Copyright &copy; 2014-2019 <a href="http://adminlte.io">AdminLTE.io</a>.</strong> All rights
    reserved.
  </footer>

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->
	
<!--
==============================================================
Material desain untuk tampilan dashboard
untuk tampilan dashboad menggunakan boootstrap 4
dengan template adminLte V3
material ini bersifat wajib :)
=========================================================
-->
<!-- jQuery -->
<script src="<?php echo base_url() ?>asset/adminlte/plugins/jquery/jquery.min.js"> </script>
<!-- Bootstrap 4 -->
<script src="<?php echo base_url() ?>asset/adminlte/plugins/bootstrap/js/bootstrap.bundle.min.js"> </script>
<!-- AdminLTE App -->
<script src="<?php echo base_url() ?>asset/adminlte/dist/js/adminlte.min.js"> </script>
<!-- AdminLTE for demo purposes -->
<script src="<?php echo base_url() ?>asset/adminlte/dist/js/demo.js"> </script>
<!--
============================================================
Akhir material desain untuk tampilan admin
===========================================================
-->

		<!-- jquery 
		============================================  -->
		<script src="<?php echo base_url() ?>asset/js/vendor/jquery-1.11.3.min.js"> </script>
		<!-- bootstrap JS
		============================================ -->
		<script src="<?php echo base_url() ?>asset/js/bootstrap.min.js"> </script>
		<!-- wow JS
		============================================ -->
		<script src="<?php echo base_url() ?>asset/js/wow.min.js"> </script>
		<!-- price-slider JS
		============================================ -->
		<script src="<?php echo base_url() ?>asset/js/jquery-price-slider.js"> </script>
		<!-- meanmenu JS
		============================================ -->
		<script src="<?php echo base_url() ?>asset/js/jquery.meanmenu.js"> </script>
		<!-- owl.carousel JS
		============================================ -->
		<script src="<?php echo base_url() ?>asset/js/owl.carousel.min.js"> </script>
		<!-- sticky JS
		============================================ -->
		<script src="<?php echo base_url() ?>asset/js/jquery.sticky.js"> </script>
		<!-- scrollUp JS
		============================================ -->
		<script src="<?php echo base_url() ?>asset/js/jquery.scrollUp.min.js"> </script>
		<!-- mCustomScrollbar JS
		============================================ -->
		<script src="<?php echo base_url() ?>asset/js/scrollbar/jquery.mCustomScrollbar.concat.min.js"> </script>
		<script src="<?php echo base_url() ?>asset/js/scrollbar/mCustomScrollbar-active.js"> </script>
		<!-- metisMenu JS
		============================================ -->
		<script src="<?php echo base_url() ?>asset/js/metisMenu/metisMenu.min.js"> </script>
		<script src="<?php echo base_url() ?>asset/js/metisMenu/metisMenu-active.js"> </script>
		<!-- data table JS
		============================================ -->
		<script src="<?php echo base_url() ?>asset/js/data-table/bootstrap-table.js"> </script>
		<script src="<?php echo base_url() ?>asset/js/data-table/tableExport.js"> </script>
		<script src="<?php echo base_url() ?>asset/js/data-table/data-table-active.js"> </script>
		<script src="<?php echo base_url() ?>asset/js/data-table/bootstrap-table-editable.js"> </script>
		<script src="<?php echo base_url() ?>asset/js/data-table/bootstrap-editable.js"> </script>
		<script src="<?php echo base_url() ?>asset/js/data-table/bootstrap-table-resizable.js"> </script>
		<script src="<?php echo base_url() ?>asset/js/data-table/colResizable-1.5.source.js"> </script>
		<script src="<?php echo base_url() ?>asset/js/data-table/bootstrap-table-export.js"> </script>
		<!--  editable JS
		============================================ -->
		<script src="<?php echo base_url() ?>asset/js/editable/jquery.mockjax.js"> </script>
		<script src="<?php echo base_url() ?>asset/js/editable/mock-active.js"> </script>
		<script src="<?php echo base_url() ?>asset/js/editable/select2.js"> </script>
		<script src="<?php echo base_url() ?>asset/js/editable/moment.min.js"> </script>
		<script src="<?php echo base_url() ?>asset/js/editable/bootstrap-datetimepicker.js"> </script>
		<script src="<?php echo base_url() ?>asset/js/editable/bootstrap-editable.js"> </script>
		<script src="<?php echo base_url() ?>asset/js/editable/xediable-active.js"> </script>
		<!-- Chart JS
		============================================ -->
		<script src="<?php echo base_url() ?>asset/js/chart/jquery.peity.min.js"> </script>
		<script src="<?php echo base_url() ?>asset/js/peity/peity-active.js"> </script>
		<!-- tab JS
		============================================ -->
		<script src="<?php echo base_url() ?>asset/js/tab.js"> </script>
		<!-- plugins JS
		============================================ -->
		<script src="<?php echo base_url() ?>asset/js/plugins.js"> </script>
		<!-- main JS
		============================================ -->
		<script src="<?php echo base_url() ?>asset/js/main.js"> </script>

		<!-- sweetalert-->
		<script type="text/javascript" src="<?php echo base_url() ?>asset/sweet_alert/jquery-1.9.1.min.js"> </script>
		<script src="<?php echo base_url() ?>asset/sweet_alert/sweetalert.min.js"> </script>
		<script src="<?php echo base_url() ?>>asset/sweet_alert/qunit-2.9.2.js"> </script>

		<!-- chosen JS
		============================================ -->
		<script src="<?php echo base_url() ?>asset/js/chosen/chosen.jquery.js"> </script>
		<script src="<?php echo base_url() ?>asset/js/chosen/chosen-active.js"> </script>
		<!-- select2 JS
		============================================ -->
		<script src="<?php echo base_url() ?>asset/js/select2/select2.full.min.js"> </script>
		<script src="<?php echo base_url() ?>asset/js/select2/select2-active.js"> </script>

		<!-- morrisjs JS
		============================================ -->
		<script src="<?php echo base_url() ?>asset/js/sparkline/jquery.sparkline.min.js"> </script>
		<script src="<?php echo base_url() ?>asset/js/sparkline/jquery.charts-sparkline.js"> </script>
		<script src="<?php echo base_url() ?>asset/js/popper.js"> </script>
		
		
		<!-- Digunakan untuk menutup message secara otomatis
		setelah 2 detik
		 -->
		<script type="text/javascript">
			window.setTimeout(function() {
    		$(".alert").fadeTo(500, 0).slideUp(500, function(){
       	 	$(this).remove(); 
    		});
		}, 2000);
		</script>
	
</body>
</html>
