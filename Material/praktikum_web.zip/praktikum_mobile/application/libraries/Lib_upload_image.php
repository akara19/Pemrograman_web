
<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/*
Contributed By In Wahyu Widodo
*/
class Lib_upload_image {

	function do_upload_image_new($Folder,$Location,$File,$File_temp){
		if (!is_dir('./'.$Folder.'/'.$Location)) {
			mkdir('./'.$Folder.'/'.$Location, 0777, TRUE);
		}
		if(empty($File)){

			$_file=base_url().'asset/No_document.pdf';
			$_new_folder=$Folder.'/'.$Location.'/';

			$acak=random_string('sha1');
			$bersih=$_file;
			$nm=str_replace(" ","_","$bersih");
			$pisah=explode(".",$nm);
			$nama_murni_lama = preg_replace("/^(.+?);.*$/", "\\1",$pisah[0]);
			$nama_murni=strtolower($nama_murni_lama);
			$ekstensi_kotor = $pisah[1];

			$file_type = preg_replace("/^(.+?);.*$/", "\\1", $ekstensi_kotor);
			$file_type_baru = strtolower($file_type);

			$ubah=$acak;
			$n_baru = $ubah.'.'.$file_type_baru;
			file_put_contents($_new_folder.$n_baru, file_get_contents($_file));
		}else{
			$acak=random_string('sha1');
			$bersih=$File;
			$nm=str_replace(" ","_","$bersih");
			$pisah=explode(".",$nm);
			$nama_murni_lama = preg_replace("/^(.+?);.*$/", "\\1",$pisah[0]);
			$nama_murni=strtolower($nama_murni_lama);
			$ekstensi_kotor = $pisah[1];

			$file_type = preg_replace("/^(.+?);.*$/", "\\1", $ekstensi_kotor);
			$file_type_baru = strtolower($file_type);

			$ubah=$acak;
			$n_baru = $ubah.'.'.$file_type_baru;
			$ori_src=$Folder.'/'.$Location.'/'.str_replace(' ','_',$n_baru);

			if(move_uploaded_file ($File_temp,$ori_src)){
				chmod("$ori_src",0777);
			}else{
				echo "Gagal melakukan proses upload file.
				Hal ini biasanya disebabkan ukuran file yang terlalu besar atau
				koneksi jaringan anda sedang bermasalah <br>";
				exit;
			}
		}
		return $n_baru;
	}

	function do_upload_image_update($Folder,$Location,$File,$File_temp,$Old_file){
		if (!is_dir('./'.$Folder.'/'.$Location)) {
			mkdir('./'.$Folder.'/'.$Location, 0777, TRUE);
		}
		if (empty($File)){
			$n_baru = $Old_file;
		}else{
			$acak=random_string('sha1');
			$bersih=$File;
			$nm=str_replace(" ","_","$bersih");
			$pisah=explode(".",$nm);
			$nama_murni_lama = preg_replace("/^(.+?);.*$/", "\\1",$pisah[0]);
			$nama_murni=strtolower($nama_murni_lama);
			$ekstensi_kotor = $pisah[1];

			$file_type = preg_replace("/^(.+?);.*$/", "\\1", $ekstensi_kotor);
			$file_type_baru = strtolower($file_type);
			$ubah=$acak;
			$n_baru = $ubah.'.'.$file_type_baru;
			$ori_src=$Folder.'/'.$Location.'/'.str_replace(' ','_',$n_baru);
			if(move_uploaded_file ($File_temp,$ori_src)){
				chmod("$ori_src",0777);
			}else{
				echo "Gagal melakukan proses upload file.
				Hal ini biasanya disebabkan ukuran file yang terlalu besar atau
				koneksi jaringan anda sedang bermasalah";
				exit;
			}
			// Untuk mengecek dan menghapus berkas yang sudah ada
			$filename =$Folder.'/'.$Location.'/'.$Old_file;
			if(file_exists($filename)){
				unlink($filename);
			}
			/* ========================================== */
		}
		return $n_baru;
	}

  function do_upload_image_new_get_name($Folder,$Location,$File,$File_temp){
		if (!is_dir('./'.$Folder.'/'.$Location)) {
			mkdir('./'.$Folder.'/'.$Location, 0777, TRUE);
		}
		if(empty($File)){
			$_file=base_url().'asset/no_image.png';
			$_new_folder=$Folder.'/'.$Location.'/';
			$acak=random_string('sha1');
			$ubah=$acak;
			$n_baru = $ubah.'.pdf';
			file_put_contents($_new_folder.$n_baru, file_get_contents($_file));
		}else{
			$acak=random_string('sha1');
			$ubah=$acak;
			$n_baru = $ubah;
      $ori_src=$Folder.'/'.$Location.'/'.$File;

			if(move_uploaded_file ($File_temp,$ori_src)){
				chmod("$ori_src",0777);
			}else{
				echo "Gagal melakukan proses upload file.
				Hal ini biasanya disebabkan ukuran file yang terlalu besar atau
				koneksi jaringan anda sedang bermasalah <br>";
				exit;
			}
		}
		return $n_baru;
	}

	function do_upload_image_update_get_name($Folder,$Location,$File,$File_temp,$Old_file){
		if (!is_dir('./'.$Folder.'/'.$Location)) {
			mkdir('./'.$Folder.'/'.$Location, 0777, TRUE);
		}
		if (empty($File)){
			$n_baru = $Old_file;
		}else{
			$acak=random_string('sha1');
		 $ubah=$acak;
			$n_baru = $ubah;
			$ori_src=$Folder.'/'.$Location.'/'.$File;
			//echo $ori_src;
			if(move_uploaded_file ($File_temp,$ori_src)){
				chmod("$ori_src",0777);
				//echo "Upload Berhasil";
			}else{
				echo "Gagal melakukan proses upload file.
				Hal ini biasanya disebabkan ukuran file yang terlalu besar atau
				koneksi jaringan anda sedang bermasalah";
				exit;
			}
			// Untuk mengecek dan menghapus berkas yang sudah ada
			$filename =$Folder.'/'.$Location.'/'.$Old_file;
			if(file_exists($filename)){
				unlink($filename);
			}
			/* ========================================== */
		}
		return $n_baru;
	}

	function Test($data){
		$this->CI =& get_instance();
		return $data;
	}

}
